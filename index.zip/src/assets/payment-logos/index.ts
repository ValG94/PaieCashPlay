import amexLogo from './american-express-logo.svg';
import visaLogo from './visa-logo.svg';
import mastercardLogo from './Mastercard-Logo.svg';

export const paymentLogos = {
  visa: visaLogo,
  mastercard: mastercardLogo,
  amex: amexLogo
};